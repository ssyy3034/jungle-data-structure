// test_bst_questions_allinone.c
// Build: gcc -std=c11 -O2 test_bst_questions_allinone.c -o bst_tests
// Run  : ./bst_tests
//
// CE1007/CZ1007 Data Structures — Section F (Q1~Q5) 통합 테스트
// - 스펙 함수명: levelOrderIterative, inOrderIterative, preOrderIterative,
//               postOrderIterativeS1(1스택), postOrderIterativeS2(2스택)
// - 트리 빌더/정리/캡처는 테스트 파일 안에서 제공

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <fcntl.h>

////////////////////////////////////////////////////////////////////////////////
// (옵션) 네 구현이 예전 함수명이면, 아래 주석 해제해서 “호환 모드”로 테스트해도 됨.
// #define levelOrderIterative     levelOrderTraversal
// #define inOrderIterative        inOrderTraversal
// #define preOrderIterative       preOrderTraversal
// #define postOrderIterativeS2    postOrderTraversal
// // (S1은 단일 스택 버전이 필요. 네가 S1을 별도로 안 만들었다면 S2만 테스트해도 OK)

////////////////////////////////////////////////////////////////////////////////
// BST 구조체
typedef struct _bstnode{
    int item;
    struct _bstnode *left;
    struct _bstnode *right;
} BSTNode;

////////////////////////////////////////////////////////////////////////////////
// 스펙상 제출 함수 프로토타입 (테스트는 이 심볼들을 호출)
void levelOrderIterative(BSTNode *root);          // Q1
void inOrderIterative(BSTNode *root);             // Q2
void preOrderIterative(BSTNode *root);            // Q3
void postOrderIterativeS1(BSTNode *root);         // Q4 (single-stack)
void postOrderIterativeS2(BSTNode *root);         // Q5 (two-stacks)

////////////////////////////////////////////////////////////////////////////////
// 테스트 유틸: 삽입/해제/출력 캡처
static void insertBSTNode(BSTNode **node, int value){
    if (*node == NULL){
        *node = (BSTNode*)malloc(sizeof(BSTNode));
        if (*node){ (*node)->item=value; (*node)->left=(*node)->right=NULL; }
        return;
    }
    if (value < (*node)->item)      insertBSTNode(&((*node)->left), value);
    else if (value > (*node)->item) insertBSTNode(&((*node)->right), value);
}

static void removeAll(BSTNode **node){
    if (*node){
        removeAll(&(*node)->left);
        removeAll(&(*node)->right);
        free(*node); *node=NULL;
    }
}

// stdout 캡처
static int saved_stdout_fd = -1;
static const char *CAP = "capture_stdout.txt";
static void begin_capture(void){
    fflush(stdout);
    saved_stdout_fd = dup(fileno(stdout));
    int fd = open(CAP, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    dup2(fd, fileno(stdout)); close(fd);
}
static void end_capture(void){
    fflush(stdout);
    if (saved_stdout_fd != -1){
        dup2(saved_stdout_fd, fileno(stdout));
        close(saved_stdout_fd);
        saved_stdout_fd = -1;
    }
}
static void read_capture(char *out, size_t cap){
    FILE *f=fopen(CAP,"r"); if(!f){*out='\0';return;}
    size_t n=fread(out,1,cap-1,f); out[n]='\0'; fclose(f);
}

////////////////////////////////////////////////////////////////////////////////
// 공용 샘플 트리:  {20,15,50,10,18,25,80}
static void build_example(BSTNode **root){
    int vals[] = {20,15,50,10,18,25,80};
    *root = NULL;
    for (int i=0;i<7;i++) insertBSTNode(root, vals[i]);
}

////////////////////////////////////////////////////////////////////////////////
// 테스트 (스펙의 예시 출력과 일치하는지 검증)
static void test_Q1_level(){
    BSTNode *r=NULL; build_example(&r);
    begin_capture(); levelOrderIterative(r); end_capture();
    char got[256]={0}; read_capture(got,sizeof(got));
    // 예시: 20 15 50 10 18 25 80
    assert(strcmp(got,"20 15 50 10 18 25 80 ")==0);
    removeAll(&r);
    printf("[Q1] levelOrderIterative ✓\n");
}

static void test_Q2_inorder(){
    BSTNode *r=NULL; build_example(&r);
    begin_capture(); inOrderIterative(r); end_capture();
    char got[256]={0}; read_capture(got,sizeof(got));
    // 예시: 10 15 18 20 25 50 80
    assert(strcmp(got,"10 15 18 20 25 50 80 ")==0);
    removeAll(&r);
    printf("[Q2] inOrderIterative ✓\n");
}

static void test_Q3_preorder(){
    BSTNode *r=NULL; build_example(&r);
    begin_capture(); preOrderIterative(r); end_capture();
    char got[256]={0}; read_capture(got,sizeof(got));
    // 예시: 20 15 10 18 50 25 80
    assert(strcmp(got,"20 15 10 18 50 25 80 ")==0);
    removeAll(&r);
    printf("[Q3] preOrderIterative ✓\n");
}

static void test_Q4_postorder_S1(){
    BSTNode *r=NULL; build_example(&r);
    begin_capture(); postOrderIterativeS1(r); end_capture();
    char got[256]={0}; read_capture(got,sizeof(got));
    // 예시: 10 18 15 25 80 50 20
    assert(strcmp(got,"10 18 15 25 80 50 20 ")==0);
    removeAll(&r);
    printf("[Q4] postOrderIterativeS1 ✓\n");
}

static void test_Q5_postorder_S2(){
    BSTNode *r=NULL; build_example(&r);
    begin_capture(); postOrderIterativeS2(r); end_capture();
    char got[256]={0}; read_capture(got,sizeof(got));
    // 예시: 10 18 15 25 80 50 20
    assert(strcmp(got,"10 18 15 25 80 50 20 ")==0);
    removeAll(&r);
    printf("[Q5] postOrderIterativeS2 ✓\n");
}

int main(void){
    printf("==== Section F — BST Iterative Traversals Auto Test ====\n");
    test_Q1_level();
    test_Q2_inorder();
    test_Q3_preorder();
    test_Q4_postorder_S1();
    test_Q5_postorder_S2();
    printf("\n✅ ALL TESTS PASSED\n");
    return 0;
}
